import { Component, OnInit } from '@angular/core';
import { MenuService } from '../menu.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-menu-item-details',
  templateUrl: './menu-item-details.component.html',
  styleUrls: ['./menu-item-details.component.scss']
})
export class MenuItemDetailsComponent implements OnInit {
  menuItemId: number;
  fooditemdata:any;

  constructor(
    private menuService: MenuService,
    private router: Router
  ) { }

  ngOnInit() {
    this.fooditemdata = this.menuService.getfidata();
    console.log(this.fooditemdata);
    if(!this.fooditemdata) {
      this.router.navigate(['menu-list']);
    }
  }

  goBack() {
    window.history.back();
  }
}
