import { Component, OnInit } from '@angular/core';
import { MenuService } from '../menu.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-menu-list',
  templateUrl: './menu-list.component.html',
  styleUrls: ['./menu-list.component.scss']
})
export class MenuListComponent implements OnInit {

  panelOpenState = false;
  data:any;

  constructor(
    private menuService: MenuService,
    private router: Router
  ) { }

  async ngOnInit() {
    await this.menuService.getGata().then(x => this.data = x);
  }

  navigateToDetails(fi,lat) {
    this.menuService.setfidata(fi,lat);
    this.router.navigate(['menu-item-details', encodeURIComponent(fi.food_name)]);
  }
}
