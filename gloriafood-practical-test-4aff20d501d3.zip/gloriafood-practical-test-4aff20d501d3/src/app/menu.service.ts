import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MenuService {

  constructor(private http: HttpClient) { }

  private fi_data = null;

  getGata() {
    return this.http.get('assets/data.json').toPromise();
  }
  
  setfidata(fi,lat) {
    this.fi_data = {"parent": lat, "child": fi};
  }

  getfidata() {
    return this.fi_data;
  }

}
